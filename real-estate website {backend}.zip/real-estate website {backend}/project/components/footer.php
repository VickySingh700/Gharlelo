<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:+91-7004713343"><i class="fas fa-phone"></i><span>+91-7004713343</span></a>
         <a href="tel:=91-7479797507"><i class="fas fa-phone"></i><span>+91-7479797507</span></a>
         <a href="mailto:vicky70047@gmail.com"><i class="fas fa-envelope"></i><span>vicky70047@gmail.com</span></a>
         <a href="https://maps.app.goo.gl/bvUCMf6DLw3yPk3F7"><i class="fas fa-map-marker-alt"></i><span>Hajipur, India - 844101</span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>home</span></a>
         <a href="about.php"><span>about</span></a>
         <a href="contact.php"><span>contact</span></a>
         <a href="listings.php"><span>all listings</span></a>
         <a href="saved.php"><span>saved properties</span></a>
      </div>

      <div class="box">
         <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>WebStyler.io</span> | all rights reserved!</div>

</footer>

<!-- footer section ends -->